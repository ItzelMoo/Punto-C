//50. E.P. que lea un vector de 50 elementos y los imprima.
	
#include <stdio.h>
#define NUM 4
int main()
{
	int nums [NUM] ;// Declaracion de variables
	int i;
	for (i = 0; i < NUM; i++)
	{
		printf("Por favor, introduzca el n�mero: ");
		scanf ("%d", &nums [i] ) ;//Entrada
	}
	printf ("\nVector de n�meros : " ) ;//Salida
		 for (i = 0; i < NUM; i++)
		 {
			 printf ("%d ",nums [i] ) ;
		 }			
	return 0;						
}



//Revis�: Programadores Empedernidos.
//-El c�digo cumple su funci�n.
//-No se debe poner acentos en el printf, ya que mmuchos IDE no lo compilan adecuadamente.
//-Las variables tienen nombres representativos.
